package views;

public enum MenuEnumeration {
	List, Add, Edit, Delete, View, Exit			
}
