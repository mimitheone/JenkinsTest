package com.phonebookconsole.tools;

public class ConfigurationManager {

    public static String GetDefaultFileEncoding() {

        return "utf-8";
    }

    public static String TempFilePrefix() {

        return "temp_";
    }
}