package com.phonebookconsole.views;

public enum MenuEnumeration {
    List, Add, Edit, Delete, View, Exit
}
